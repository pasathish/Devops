# EKS GitHub Runners Terraform Module

This Terraform module creates a private Amazon EKS cluster optimized for GitHub Actions runners using Bottlerocket AMI. The cluster is designed with security, performance, and cost optimization in mind.

## Features

- **🚀 Private EKS Cluster**: Fully private cluster with no public endpoint access by default
- **🐧 Bottlerocket AMI**: Purpose-built Linux distribution for containers with enhanced security
- **🔐 IRSA Support**: Built-in IAM Roles for Service Accounts configuration
- **🛡️ Security Groups**: Properly configured security groups for cluster and nodes
- **🔑 aws-auth ConfigMap**: Automatic configuration of node group authentication
- **📊 CloudWatch Logging**: Integrated logging for cluster and node monitoring
- **🏷️ Proper Tagging**: Consistent resource tagging with naming conventions
- **⚙️ EKS Add-ons**: Configurable add-ons (VPC CNI, CoreDNS, kube-proxy, EBS CSI)
- **🔧 Customizable**: Extensive configuration options for different environments

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        Private VPC                             │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐ │
│  │   Private       │  │   Private       │  │   Private       │ │
│  │   Subnet 1      │  │   Subnet 2      │  │   Subnet 3      │ │
│  │   (AZ-1)        │  │   (AZ-2)        │  │   (AZ-3)        │ │
│  │                 │  │                 │  │                 │ │
│  │ ┌─────────────┐ │  │ ┌─────────────┐ │  │ ┌─────────────┐ │ │
│  │ │ Bottlerocket│ │  │ │ Bottlerocket│ │  │ │ Bottlerocket│ │ │
│  │ │ Nodes       │ │  │ │ Nodes       │ │  │ │ Nodes       │ │ │
│  │ │ (GitHub     │ │  │ │ (GitHub     │ │  │ │ (GitHub     │ │ │
│  │ │ Runners)    │ │  │ │ Runners)    │ │  │ │ Runners)    │ │ │
│  │ └─────────────┘ │  │ └─────────────┘ │  │ └─────────────┘ │ │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘ │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                EKS Control Plane                       │   │
│  │              (Private Access Only)                     │   │
│  └─────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
```

## Usage

### Basic Usage

```hcl
# Configure Kubernetes provider for aws-auth ConfigMap
provider "kubernetes" {
  host                   = module.eks_github_runners.cluster_endpoint
  cluster_ca_certificate = base64decode(module.eks_github_runners.cluster_certificate_authority_data)
  
  exec {
    api_version = "client.authentication.k8s.io/v1beta1"
    command     = "aws"
    args        = ["eks", "get-token", "--cluster-name", module.eks_github_runners.cluster_id]
  }
}

module "eks_github_runners" {
  source = "./terraform-modules/eks-github-runners"

  # Required Variables
  project_name     = "my-project"
  environment      = "dev"
  vpc_id           = "vpc-12345678"
  vpc_cidr         = "10.0.0.0/16"
  private_subnet_ids = [
    "subnet-12345678",
    "subnet-23456789", 
    "subnet-34567890"
  ]

  # IAM Role ARNs (passed explicitly)
  cluster_service_role_arn = "arn:aws:iam::123456789012:role/eks-cluster-service-role"
  node_group_role_arn      = "arn:aws:iam::123456789012:role/eks-node-group-role"
  kms_key_arn             = "arn:aws:kms:us-east-1:123456789012:key/12345678-1234-1234-1234-123456789012"

  # Optional Configuration
  kubernetes_version = "1.28"
  instance_types     = ["m5.large", "m5.xlarge"]
  desired_capacity   = 3
  min_capacity       = 1
  max_capacity       = 10

  common_tags = {
    "Owner"       = "DevOps Team"
    "Project"     = "GitHub Runners"
    "Environment" = "Development"
  }
}
```

### Advanced Configuration

```hcl
module "eks_github_runners" {
  source = "./terraform-modules/eks-github-runners"

  # Required Variables
  project_name       = "github-enterprise"
  environment        = "production"
  vpc_id             = var.vpc_id
  vpc_cidr           = var.vpc_cidr
  private_subnet_ids = var.private_subnet_ids

  # IAM Roles
  cluster_service_role_arn = module.iam_roles.cluster_service_role_arn
  node_group_role_arn      = module.iam_roles.node_group_role_arn
  kms_key_arn             = module.kms.key_arn

  # Cluster Configuration
  kubernetes_version           = "1.28"
  enable_public_access        = false
  enabled_cluster_log_types   = ["api", "audit", "authenticator"]

  # Node Configuration
  instance_types        = ["m5.xlarge", "m5.2xlarge"]
  capacity_type         = "ON_DEMAND"
  desired_capacity      = 5
  min_capacity          = 2
  max_capacity          = 20
  enable_dedicated_nodes = true

  # Storage Configuration
  root_volume_size = 30

  # Remote Access
  enable_remote_access = true
  key_pair_name       = "github-runners-key"

  # Bottlerocket Configuration
  enable_cloudwatch_logging = true

  # Add-ons with IRSA
  enable_vpc_cni_addon = true
  vpc_cni_role_arn    = module.iam_roles.vpc_cni_role_arn
  
  enable_ebs_csi_addon = true
  ebs_csi_role_arn    = module.iam_roles.ebs_csi_role_arn

  # Logging
  log_retention_days = 30

  # Tags
  common_tags = {
    "Environment"   = "production"
    "Project"       = "github-enterprise"
    "ManagedBy"     = "terraform"
    "Owner"         = "platform-team"
    "CostCenter"    = "engineering"
    "Backup"        = "required"
  }
}
```

### With Fargate Support

```hcl
# Create the EKS cluster with Bottlerocket nodes
module "eks_github_runners" {
  source = "./terraform-modules/eks-github-runners"

  # ... basic configuration ...
}

# Add Fargate profile for additional workloads
resource "aws_eks_fargate_profile" "github_runners_fargate" {
  cluster_name           = module.eks_github_runners.cluster_id
  fargate_profile_name   = "github-runners-fargate"
  pod_execution_role_arn = var.fargate_pod_execution_role_arn
  subnet_ids             = var.private_subnet_ids

  selector {
    namespace = "github-runners"
    labels = {
      "compute-type" = "fargate"
    }
  }
}
```

## Requirements

| Name | Version |
|------|---------|
| terraform | >= 1.5 |
| aws | >= 5.0 |
| tls | >= 4.0 |

## Providers

| Name | Version |
|------|---------|
| aws | >= 5.0 |
| tls | >= 4.0 |

## Inputs

### Required Inputs

| Name | Description | Type |
|------|-------------|------|
| project_name | Name of the project. Used in resource naming. | `string` |
| environment | Environment name (e.g., dev, staging, prod) | `string` |
| vpc_id | ID of the VPC where the EKS cluster will be created | `string` |
| vpc_cidr | CIDR block of the VPC | `string` |
| private_subnet_ids | List of private subnet IDs for the EKS cluster and nodes (must be 3 subnets) | `list(string)` |
| cluster_service_role_arn | ARN of the IAM role for EKS cluster service | `string` |
| node_group_role_arn | ARN of the IAM role for EKS node group | `string` |
| kms_key_arn | ARN of KMS key for encryption | `string` |

### Optional Inputs

| Name | Description | Type | Default |
|------|-------------|------|---------|
| kubernetes_version | Kubernetes version for the EKS cluster | `string` | `"1.28"` |
| enable_public_access | Enable public access to EKS API server endpoint | `bool` | `false` |
| public_access_cidrs | List of CIDR blocks for public access to EKS API | `list(string)` | `["0.0.0.0/0"]` |
| enabled_cluster_log_types | List of enabled EKS cluster log types | `list(string)` | `["api", "audit", "authenticator", "controllerManager", "scheduler"]` |
| instance_types | List of EC2 instance types for the node group | `list(string)` | `["m5.large", "m5.xlarge"]` |
| capacity_type | Type of capacity associated with the EKS Node Group | `string` | `"ON_DEMAND"` |
| desired_capacity | Desired number of nodes in the node group | `number` | `2` |
| min_capacity | Minimum number of nodes in the node group | `number` | `1` |
| max_capacity | Maximum number of nodes in the node group | `number` | `10` |
| root_volume_size | Size of the root volume for Bottlerocket nodes in GB | `number` | `20` |
| enable_remote_access | Enable remote access to worker nodes | `bool` | `false` |
| key_pair_name | Name of the EC2 Key Pair for remote access to nodes | `string` | `""` |
| enable_dedicated_nodes | Enable taints for dedicated GitHub runner nodes | `bool` | `true` |
| enable_cloudwatch_logging | Enable CloudWatch logging for Bottlerocket nodes | `bool` | `true` |
| log_retention_days | Number of days to retain CloudWatch logs | `number` | `14` |
| common_tags | Common tags to apply to all resources | `map(string)` | `{}` |

### Add-on Configuration

| Name | Description | Type | Default |
|------|-------------|------|---------|
| enable_vpc_cni_addon | Enable VPC CNI addon | `bool` | `true` |
| vpc_cni_version | Version of VPC CNI addon | `string` | `null` |
| vpc_cni_role_arn | ARN of IAM role for VPC CNI addon | `string` | `""` |
| enable_coredns_addon | Enable CoreDNS addon | `bool` | `true` |
| coredns_version | Version of CoreDNS addon | `string` | `null` |
| enable_kube_proxy_addon | Enable kube-proxy addon | `bool` | `true` |
| kube_proxy_version | Version of kube-proxy addon | `string` | `null` |
| enable_ebs_csi_addon | Enable EBS CSI driver addon | `bool` | `true` |
| ebs_csi_version | Version of EBS CSI driver addon | `string` | `null` |
| ebs_csi_role_arn | ARN of IAM role for EBS CSI driver addon | `string` | `""` |

## Outputs

### Cluster Information

| Name | Description |
|------|-------------|
| cluster_id | Name/ID of the EKS cluster |
| cluster_arn | ARN of the EKS cluster |
| cluster_endpoint | Endpoint for EKS control plane |
| cluster_version | Kubernetes server version for the EKS cluster |
| cluster_status | Status of the EKS cluster |
| cluster_certificate_authority_data | Base64 encoded certificate data |

### IRSA Configuration

| Name | Description |
|------|-------------|
| oidc_provider_arn | ARN of the OIDC Provider for IRSA |
| oidc_provider_url | URL of the OIDC Provider |
| oidc_issuer_url | The URL on the EKS cluster for the OpenID Connect identity provider |
| irsa_condition_key | IRSA condition key for service account role trust policies |

### Security Groups

| Name | Description |
|------|-------------|
| cluster_security_group_id | Security group ID attached to the EKS cluster |
| node_security_group_id | Security group ID attached to the EKS node group |

### Node Group Information

| Name | Description |
|------|-------------|
| node_group_id | EKS node group ID |
| node_group_arn | Amazon Resource Name (ARN) of the EKS Node Group |
| node_group_status | Status of the EKS Node Group |
| bottlerocket_ami_id | ID of the Bottlerocket AMI used for nodes |

### GitHub Actions Integration

| Name | Description |
|------|-------------|
| github_runner_node_selector | Node selector for GitHub Actions runners |
| github_runner_tolerations | Tolerations for GitHub Actions runners |

### Useful Commands

| Name | Description |
|------|-------------|
| kubectl_config_command | Command to configure kubectl for this cluster |
| useful_commands | Map of useful commands for managing the cluster |

## Bottlerocket Configuration

This module uses AWS Bottlerocket AMI, which provides:

- **Enhanced Security**: Purpose-built OS with minimal attack surface
- **Automatic Updates**: Built-in update mechanism
- **Container Optimized**: Optimized for running containers
- **Immutable Infrastructure**: Read-only root filesystem

### Bottlerocket Features Enabled

- Custom user data configuration for EKS integration
- CloudWatch logging integration
- Container runtime optimization
- Network and kernel security settings
- Optional admin container for debugging

## Security Considerations

### Network Security

- Private EKS cluster by default (no public endpoint)
- Security groups with least privilege access
- VPC-native networking with proper subnet isolation
- Encrypted EBS volumes with customer-managed KMS keys

### IAM Security

- IRSA (IAM Roles for Service Accounts) support
- Separate IAM roles for cluster and nodes
- Explicit IAM role ARN passing (no automatic role creation)
- Proper service account configurations for add-ons

### Container Security

- Bottlerocket OS with enhanced security features
- Encrypted container storage
- Security group isolation between nodes
- Optional dedicated node taints for GitHub runners

## Cost Optimization

### Instance Management

- Configurable instance types and sizes
- Support for Spot instances (`capacity_type = "SPOT"`)
- Auto-scaling configuration
- Right-sized storage volumes

### Resource Optimization

- EBS GP3 volumes with optimized IOPS/throughput
- CloudWatch log retention configuration
- Optional add-ons to reduce unnecessary costs
- Proper resource tagging for cost allocation

## Monitoring and Logging

### CloudWatch Integration

- EKS control plane logging
- Bottlerocket node logging
- Configurable log retention
- Performance monitoring

### Available Log Types

- API server logs
- Audit logs
- Authenticator logs
- Controller manager logs
- Scheduler logs

## Examples

### Development Environment

```hcl
module "eks_dev" {
  source = "./terraform-modules/eks-github-runners"

  project_name       = "myapp"
  environment        = "dev"
  vpc_id             = "vpc-dev123"
  vpc_cidr           = "10.0.0.0/16"
  private_subnet_ids = ["subnet-1", "subnet-2", "subnet-3"]

  cluster_service_role_arn = "arn:aws:iam::123456789012:role/eks-cluster-dev"
  node_group_role_arn      = "arn:aws:iam::123456789012:role/eks-nodes-dev"
  kms_key_arn             = "arn:aws:kms:us-east-1:123456789012:key/dev-key"

  # Dev-specific settings
  instance_types     = ["t3.medium"]
  desired_capacity   = 1
  min_capacity       = 1
  max_capacity       = 3
  capacity_type      = "SPOT"

  enable_remote_access = true
  key_pair_name       = "dev-key"
  
  log_retention_days = 7
}
```

### Production Environment

```hcl
module "eks_prod" {
  source = "./terraform-modules/eks-github-runners"

  project_name       = "myapp"
  environment        = "prod"
  vpc_id             = "vpc-prod123"
  vpc_cidr           = "10.1.0.0/16"
  private_subnet_ids = ["subnet-prod-1", "subnet-prod-2", "subnet-prod-3"]

  cluster_service_role_arn = "arn:aws:iam::123456789012:role/eks-cluster-prod"
  node_group_role_arn      = "arn:aws:iam::123456789012:role/eks-nodes-prod"
  kms_key_arn             = "arn:aws:kms:us-east-1:123456789012:key/prod-key"

  # Production settings
  kubernetes_version = "1.28"
  instance_types     = ["m5.xlarge", "m5.2xlarge"]
  desired_capacity   = 5
  min_capacity       = 3
  max_capacity       = 20
  capacity_type      = "ON_DEMAND"

  # Enhanced storage for production
  root_volume_size      = 50
  container_volume_size = 200

  # Production security
  enable_dedicated_nodes    = true
  enable_remote_access      = false
  enable_cloudwatch_logging = true

  # Add-ons with IRSA
  vpc_cni_role_arn = "arn:aws:iam::123456789012:role/vpc-cni-prod"
  ebs_csi_role_arn = "arn:aws:iam::123456789012:role/ebs-csi-prod"

  log_retention_days = 90

  common_tags = {
    Environment = "production"
    Critical    = "true"
    Backup      = "required"
  }
}
```

## Troubleshooting

### Common Issues

1. **Node Group Creation Fails**
   - Verify subnet IDs are in different AZs
   - Check IAM role permissions
   - Ensure security groups allow required traffic

2. **Bottlerocket Nodes Not Joining**
   - Verify user data configuration
   - Check security group rules
   - Review CloudWatch logs

3. **Add-on Installation Fails**
   - Verify IRSA role ARNs are correct
   - Check add-on compatibility with Kubernetes version
   - Review add-on specific requirements

### Debugging Commands

```bash
# Configure kubectl
aws eks update-kubeconfig --region us-east-1 --name <cluster-name>

# Check cluster status
kubectl cluster-info

# Check node status
kubectl get nodes -o wide

# Check system pods
kubectl get pods -n kube-system

# View node details
kubectl describe node <node-name>

# Check add-on status
aws eks describe-addon --cluster-name <cluster-name> --addon-name <addon-name>
```

## Contributing

When contributing to this module:

1. Follow Terraform best practices
2. Update documentation for any new variables or outputs
3. Add validation rules for new variables
4. Test in multiple environments
5. Update examples as needed

## License

This module is released under the MIT License. See LICENSE file for details.
