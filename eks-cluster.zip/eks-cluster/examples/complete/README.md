# Complete EKS GitHub Runners Example

This example demonstrates how to use the EKS GitHub Runners module with existing AWS networking infrastructure.

## Prerequisites

Before using this example, you must have the following AWS resources already created:

### Required Network Infrastructure

1. **VPC** - An existing VPC with DNS hostnames and DNS support enabled
2. **Private Subnets** - Exactly 3 private subnets in different Availability Zones
3. **Internet Access** - Private subnets must have outbound internet access (via NAT Gateway)

### Required Subnet Tags

Your private subnets should have the following tags for proper EKS integration:

```
kubernetes.io/role/internal-elb = 1
kubernetes.io/cluster/<cluster-name> = owned  # or "shared" if used by multiple clusters
```

### IAM Permissions

Ensure your Terraform execution role has permissions to:
- Create and manage EKS clusters and node groups
- Create and manage IAM roles and policies
- Create and manage KMS keys
- Create and manage CloudWatch log groups
- Manage Kubernetes resources (aws-auth ConfigMap)

## Usage

1. **Copy the example variables file:**
   ```bash
   cp terraform.tfvars.example terraform.tfvars
   ```

2. **Edit terraform.tfvars with your values:**
   ```hcl
   # Replace with your actual resource IDs
   vpc_id = "vpc-your-vpc-id"
   vpc_cidr = "10.0.0.0/16"  # Your VPC's CIDR
   private_subnet_ids = [
     "subnet-your-subnet-1",
     "subnet-your-subnet-2", 
     "subnet-your-subnet-3"
   ]
   
   # Customize other settings as needed
   project_name = "your-project"
   environment = "your-env"
   ```

3. **Initialize Terraform:**
   ```bash
   terraform init
   ```

4. **Plan the deployment:**
   ```bash
   terraform plan
   ```

5. **Apply the configuration:**
   ```bash
   terraform apply
   ```

## What This Example Creates

- **EKS Cluster**: Private cluster with Bottlerocket node group
- **IAM Roles**: Cluster service role and node group role with required policies
- **Security Groups**: Properly configured for cluster and node communication  
- **KMS Key**: For EKS secrets encryption
- **CloudWatch Logs**: For cluster and node logging
- **aws-auth ConfigMap**: For node authentication
- **OIDC Provider**: For IRSA (IAM Roles for Service Accounts)

## Configuration Options

The example supports extensive customization through variables:

### Environment-Specific Examples

**Development:**
```hcl
project_name = "myapp-dev"
environment = "dev"
instance_types = ["t3.medium"]
capacity_type = "SPOT"
desired_capacity = 1
max_capacity = 3
```

**Production:**
```hcl
project_name = "myapp-prod"
environment = "production"
instance_types = ["m5.xlarge", "m5.2xlarge"]
capacity_type = "ON_DEMAND"
desired_capacity = 5
max_capacity = 20
```

## After Deployment

### Configure kubectl

```bash
aws eks update-kubeconfig --region us-east-1 --name <cluster-name>
```

### Verify Cluster

```bash
kubectl get nodes
kubectl get pods -n kube-system
```

### Deploy GitHub Actions Runner Controller

Follow the [Actions Runner Controller documentation](https://github.com/actions/actions-runner-controller) to deploy ARC to your cluster.

## Network Requirements Details

### Private Subnets Must Have:

1. **Outbound Internet Access**: Via NAT Gateway for:
   - Pulling container images from ECR
   - Downloading GitHub Actions from github.com  
   - AWS API calls
   - Package updates

2. **No Inbound Internet Access**: For security

3. **Cross-AZ Distribution**: For high availability

### Security Groups

The module creates security groups that allow:
- Communication between cluster and nodes
- Node-to-node communication
- Egress to internet for updates and API calls
- Ingress from VPC CIDR for management

## Troubleshooting

### Common Issues

1. **Nodes not joining cluster:**
   - Check aws-auth ConfigMap: `kubectl get configmap aws-auth -n kube-system -o yaml`
   - Verify IAM role permissions
   - Check security group rules

2. **No internet access from nodes:**
   - Verify NAT Gateway in public subnet
   - Check route table associations
   - Verify security group egress rules

3. **kubectl access denied:**
   - Run: `aws eks update-kubeconfig --region <region> --name <cluster-name>`
   - Verify IAM permissions for cluster access

### Useful Commands

```bash
# Get cluster info
kubectl cluster-info

# Check node status
kubectl get nodes -o wide

# Check system pods
kubectl get pods -n kube-system

# Describe a node
kubectl describe node <node-name>

# Check AWS auth ConfigMap
kubectl get configmap aws-auth -n kube-system -o yaml
```

## Cleanup

To destroy all resources:

```bash
terraform destroy
```

**Note**: This will not delete the VPC and subnets since they were provided as input variables.

## Cost Considerations

- EKS cluster: ~$73/month (control plane)
- Worker nodes: Variable based on instance types and count
- NAT Gateway: ~$45/month (if you created one)
- Data transfer: Variable based on usage

Consider using Spot instances for development environments to reduce costs.
